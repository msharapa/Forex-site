Cufon.replace('h3', { fontFamily: 'Myriad Pro Light' });
Cufon.replace('h4', { fontFamily: 'Myriad Pro Light' });